import React from 'react';
import { MousePointer2 } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="min-h-screen flex flex-col justify-center px-6 md:px-24 max-w-7xl mx-auto relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-20 right-0 w-64 h-64 border border-cyan/5 rounded-full animate-[spin_10s_linear_infinite]"></div>
      <div className="absolute top-20 right-10 w-48 h-48 border border-slate/5 rounded-full animate-[spin_15s_linear_infinite_reverse]"></div>
      
      <div className="z-10 animate-[fadeIn_1s_ease-out]">
        <p className="font-mono text-cyan mb-5 tracking-widest text-sm md:text-base">
          Hi, my name is
        </p>
        
        <h1 className="font-sans font-bold text-5xl md:text-7xl lg:text-8xl text-slate-lightest mb-4 tracking-tight">
          Elmerio S. Talara.
        </h1>
        
        <h2 className="font-sans font-bold text-4xl md:text-6xl lg:text-7xl text-slate mb-8 tracking-tight">
          Bridging Silicon & Software.
        </h2>
        
        <p className="max-w-xl text-slate text-lg md:text-xl leading-relaxed mb-12">
          I'm a <span className="text-cyan">Hybrid Computer Engineer</span> specializing in full-stack engineering from transistors to AI. I build high-precision hardware prototypes and the intelligent software that brings them to life.
        </p>
        
        <a 
          href="#projects"
          className="inline-flex items-center gap-2 font-mono text-cyan border border-cyan px-6 py-4 rounded bg-transparent hover:bg-cyan/10 transition-all duration-300 text-sm md:text-base group"
        >
          Check out my projects
          <MousePointer2 size={16} className="group-hover:translate-y-1 transition-transform" />
        </a>
      </div>

      {/* Schematic Grid Overlay */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{
            backgroundImage: `linear-gradient(#64ffda 1px, transparent 1px), linear-gradient(90deg, #64ffda 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
        }}
      ></div>
    </section>
  );
};

export default Hero;