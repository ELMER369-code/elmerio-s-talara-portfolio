import React, { useState, useEffect } from 'react';
import Hero from './components/Hero';
import ProjectSection from './components/ProjectSection';
import { NAV_LINKS } from './constants';
import { Menu, X, Hexagon } from 'lucide-react';

const App: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="bg-navy min-h-screen text-slate-lightest font-sans selection:bg-cyan selection:text-navy overflow-x-hidden">
      
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-navy/90 backdrop-blur-md shadow-lg h-20' : 'bg-transparent h-24'}`}>
        <div className="max-w-7xl mx-auto px-6 md:px-12 h-full flex justify-between items-center">
          
          {/* Logo */}
          <a href="#" className="group relative z-50">
            <div className="text-cyan transition-transform group-hover:-translate-y-1">
               <Hexagon className="w-10 h-10 fill-transparent stroke-cyan stroke-2" />
               <span className="absolute inset-0 flex items-center justify-center font-mono font-bold text-cyan text-sm">H</span>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <ul className="flex gap-8 font-mono text-sm">
              {NAV_LINKS.map((link, index) => (
                <li key={link.name} className="group">
                  <a href={link.href} className="text-slate-lightest hover:text-cyan transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
            <a 
                href="/resume.pdf" 
                className="font-mono text-cyan text-sm px-4 py-2 border border-cyan rounded hover:bg-cyan/10 transition-colors"
            >
                Resume
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-cyan z-50"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={32} /> : <Menu size={32} />}
          </button>

          {/* Mobile Overlay */}
          <div className={`fixed inset-0 bg-navy z-40 flex flex-col items-center justify-center gap-8 transition-transform duration-300 md:hidden ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
             {NAV_LINKS.map((link) => (
                <a 
                    key={link.name}
                    href={link.href} 
                    className="font-mono text-xl text-slate-lightest hover:text-cyan"
                    onClick={() => setIsMobileMenuOpen(false)}
                >
                    {link.name}
                </a>
              ))}
              <a 
                href="/resume.pdf" 
                className="font-mono text-cyan text-lg px-8 py-3 border border-cyan rounded hover:bg-cyan/10"
              >
                Resume
            </a>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="w-full">
        <Hero />
        <ProjectSection />
        
        {/* Footer / Simple Contact */}
        <section id="contact" className="py-24 max-w-2xl mx-auto text-center px-6">
            <p className="font-mono text-cyan mb-4">03. What's Next?</p>
            <h2 className="font-sans font-bold text-4xl md:text-5xl text-slate-lightest mb-6">Get In Touch</h2>
            <p className="text-slate text-lg mb-12">
                Whether you have a question about my hardware prototypes, software solutions, or just want to say hi, my inbox is always open.
            </p>
            <a href="mailto:hello@example.com" className="inline-block border border-cyan text-cyan font-mono px-8 py-4 rounded hover:bg-cyan/10 transition-all">
                Say Hello
            </a>
        </section>

        <footer className="py-6 text-center text-slate font-mono text-xs">
            <p>Designed & Built by a Hybrid Engineer</p>
        </footer>
      </main>

      {/* Social Sticky Sidebars (Visual Only for Style) */}
      <div className="hidden lg:block fixed bottom-0 left-12 w-10">
        <div className="flex flex-col items-center gap-6">
             <div className="w-[1px] h-24 bg-slate-light"></div>
        </div>
      </div>
      <div className="hidden lg:block fixed bottom-0 right-12 w-10">
        <div className="flex flex-col items-center gap-6">
             <div className="w-[1px] h-24 bg-slate-light"></div>
        </div>
      </div>

    </div>
  );
};

export default App;